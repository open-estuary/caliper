build_lmbench() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi

    SrcPath="/tmp/lmbench"
    cd $SrcPath

    myOBJPATH="/tmp/lmbench.build"
    mkdir -p $myOBJPATH
    mkdir -p $myOBJPATH/src
    mkdir -p $myOBJPATH/results
    cp -r -f scripts  $myOBJPATH
    cp src/webpage-lm.tar $myOBJPATH/src
    cp -f CONFIG lmbench_latency lmbench_bandwidth test.sh test_local_bw.sh test_cross_bw.sh test_lat.sh $myOBJPATH
    make clean
    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        make OS=lmbench  CC="$GCC -O2 -msse4" -s
    fi
    if [ $ARCH = "arm_64" -o $ARCH = "aarch32" ]; then
        if [ $ARCH = "aarch32" ]; then
          make OS=lmbench  CC="$GCC -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15"
        else
            make OS=lmbench  CC=$GCC        # " -mabi=lp64"
        fi
    fi
    mv bin/lmbench/*  $myOBJPATH
    rm -rf bin
    if [ -f "$myOBIPATH/lmbench" ]; then
        sed -i 's/\.\.\/\.\.\//\.\//g' "$myOBJPATH/lmbench"
    fi
    cd $myOBJPATH/../
    tar -cvf lmbench.build.tar.gz lmbench.build
    rm -fr lmbench
}

build_lmbench
