build_netperf() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=/tmp/netperf
    myOBJPATH=/usr/bin

    if [ $ARCH = "x86_64" -o  $ARCH = "x86_32" ]
    then
        #cp $SrcPath/* ./ -rf
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ./configure
        make
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
    fi

    if [ $ARCH = "aarch64" -o $ARCH = "aarch32" ]
    then
        #cp $SrcPath/* ./ -rf
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ac_cv_func_setpgrp_void=yes ac_cv_func_malloc_0_nonnull=yes ./configure --build=arm-linux     #--host=$ARMCROSS
        make
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
    fi
}

build_netperf
