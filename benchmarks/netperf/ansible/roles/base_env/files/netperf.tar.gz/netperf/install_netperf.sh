build_netperf() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/usr/bin
    myOBJPATH=${INSTALL_DIR}/bin

    if [ $ARCH = "x86_64" -o  $ARCH = "x86_32" ]
    then
        pushd $SrcPath
        #cp $SrcPath/* ./ -rf
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ./configure
        make
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
        popd
    fi

    if [ $ARCH = "aarch64" -o $ARCH = "aarch32" ]
    then
        cd $SrcPath
        #cp $SrcPath/* ./ -rf
        aclocal -I src/missing/m4
        automake  --add-missing
        autoconf
        autoheader
        ac_cv_func_setpgrp_void=yes ac_cv_func_malloc_0_nonnull=yes ./configure      #--host=$ARMCROSS
        make CC=$GCC
        cp src/netperf $myOBJPATH
        cp src/netserver $myOBJPATH
    fi
}

build_netperf
