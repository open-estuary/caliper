build_coremark() {
   set -e
    ARCH=`uname -i`
    if [ $ARCH = "arm_32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "arm_64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/usr/bin
    CoreMarkPath=$(cd `dirname $0`; pwd)
    pushd $CoreMarkPath
    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        # -O2 -msse4
        make PORT_DIR=linux64 CC=$GCC XCFLAGS=" -msse4 " compile
    #    cp coremark.exe $myOBJPATH/coremark
    #    make PORT_DIR=linux64 CC=$GCC clean
    fi
    if [ $ARCH = "arm_32" ]; then
        # O2 -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15
        make PORT_DIR=linux CC=$GCC XCFLAGS=" -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15 " compile
    #    cp coremark.exe $myOBJPATH/coremark
    #    make PORT_DIR=linux64 CC=$GCC compile clean
    fi
    if [ $ARCH = "arm_64"  ]; then
        make PORT_DIR=linux64 CC=$GCC compile       # XCFLAGS=" -mabi=lp64 " compile
    #    cp coremark.exe $myOBJPATH/coremark
    #    make PORT_DIR=linux64 CC=$GCC clean
    fi
   popd

}

build_coremark

