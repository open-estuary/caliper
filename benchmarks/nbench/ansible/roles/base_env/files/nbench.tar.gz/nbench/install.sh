
build_nbench()
{
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "arm_32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "arm_64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/tmp/nbench
    mkdir -p $myOBJPATH
    pushd $SrcPath

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ];then
         make     
    #     cp * $myOBJPATH
    #     make CC=$GCC clean
    fi
    if [ $ARCH = "arm_32" ]; then
        make CC=$GCC CFLAGS="-mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15"     
    #    cp * $myOBJPATH
    #    make CC=$GCC clean
    fi
    if [ $ARCH = "arm_64" ]; then
        make CC=$GCC      #CFLAGS="-mabi=lp64"
    #    cp * $myOBJPATH
    #    make CC=$GCC clean
    fi
    popd
}

build_nbench
