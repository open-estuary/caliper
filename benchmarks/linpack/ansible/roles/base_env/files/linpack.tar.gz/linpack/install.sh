build_linpack() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "arm_32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "arm_64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/usr/bin/
    pushd $SrcPath
    ${GCC} -O2  -DDP -o linpack_dp linpack.c
    ${GCC} -O2 -DSP -o linpack_sp linpack.c
    mv linpack_sp $myOBJPATH/
    mv linpack_dp $myOBJPATH/
    popd

}

build_linpack
