build_dhrystone()
{
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=/tmp/dhrystone
    myOBJPATH=/usr/bin
    if [ $ARCH = "x86_64" ]; then
        make GCC=gcc unix
        #cp gcc_dry2 $myOBJPATH
    fi
    if [ $ARCH = "aarch64" ]; then
        make GCC=aarch64-linux-gnu-gcc unix
        #cp gcc_dry2 $myOBJPATH
    fi
}

build_dhrystone

