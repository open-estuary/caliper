<?php
echo "hello world\n";
?>
