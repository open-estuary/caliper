build_openssl() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "arm_32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "arm_64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/usr/bin
    BuildPATH="/tmp/build.openssl"
    mkdir -p $BuildPATH
    pushd $SrcPath
    TOP_SRCDIR="$SrcPath"
        if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
            cp -rf $TOP_SRCDIR/* $BuildPATH
            pushd $BuildPATH
            if [ $ARCH = "x86_64" ]; then
                OS_OPTION="linux-x86_64"
            else
                OS_OPTION="linux"
            fi
            CC=$GCC $TOP_SRCDIR/Configure $OS_OPTION      #linux-x86_64
            make -s    

            popd
        fi
        if [ $ARCH = "arm_32" -o $ARCH = 'arm_64' ]; then  #-o $ARCH = "arm_64"
            cp -rf $TOP_SRCDIR/* $BuildPATH/
            pushd $BuildPATH
            if [ $ARCH = "arm_32" ] ; then
                CC=$GCC ./Configure linux-armv4    
            else
                CC=$GCC ./Configure linux-aarch64    
            fi
            make -s
            popd
        fi
}

build_openssl
