build_cachebench() {
    set -e
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath=/tmp/cachebench
    myOBJPATH=/usr/bin
    if [ $ARCH = "x86_32" -o $ARCH = "x86_64" ]; then
        make CC=$GCC CFLAGS="-msse4" -s
#         mv cachebench    $myOBJPATH
    fi
    if [ $ARCH = "aarch32" ]; then
        make CC=$GCC CFLAGS="-mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15" -s
#        mv cachebench    $myOBJPATH
    fi
    if [ $ARCH = "aarch64" ]; then
        make -s       #CFLAGS="-mabi=lp64"
#       mv cachebench    $myOBJPATH
    fi
}

build_cachebench

