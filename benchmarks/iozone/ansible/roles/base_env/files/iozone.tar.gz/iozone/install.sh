build_iozone() {    
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    SrcPath="/dev/sdb"
    if [ ! -d $SrcPath ]
    then
        mkdir -p $SrcPath 
    fi
    mntpath="/mnt/sdb"
    if [ ! -d $mntpath ]
    then
        mkdir -p $mntpath
    fi
    chmod -R 775 /mnt/sdb
    chown -R root:root /mnt/sdb
    #mount /dev/sdb /mnt/sdb
    myOBJPATH=/mnt/sdb/
    if [ $ARCH = "x86_64" ]
    then
        make linux-AMD64 -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    elif [ $ARCH = "x86_32" ]; then
        make linux -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    else
        make linux-arm CC=$GCC GCC=$GCC -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    fi
}

build_iozone
