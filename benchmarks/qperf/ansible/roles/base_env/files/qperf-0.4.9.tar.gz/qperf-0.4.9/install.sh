build_scimark() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "aarch32" ]; then
        ARMCROSS=arm-linux-gnueabihf
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    elif [ $ARCH = "aarch64" ]; then
        ARMCROSS=aarch64-linux-gnu
        GCC=${ARMCROSS}-gcc
        STRIP=${ARMCROSS}-strip
    fi

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        GCC=gcc
        STRIP=strip
    fi
    myOBJPATH=/usr/bin
    if [ $ARCH = "x86_32" -o $ARCH = "x86_64" ]; then
        ./configure --build=x86_64-unknown-linux-gnu
    fi
    if [ $ARCH = "aarch32" ]; then
        # -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15
        ./configure --build=aarch32-unknown-linux-gnu
    fi
    if [ $ARCH = "aarch64" ]; then
        ./configure --build=aarch64-unknown-linux-gnu
    fi
}

build_scimark
