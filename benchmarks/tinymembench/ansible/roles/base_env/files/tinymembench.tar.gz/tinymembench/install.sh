build_tiny() {
   set -e
   ARCH=`uname -i`
   CoreMarkPath=$(cd `dirname $0`; pwd)
   myOBJPATH=/usr/bin
   pushd $CoreMarkPath
   if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
    make
   fi
   if [ $ARCH = "aarch32" ]; then
      # O2 -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15
    CC=$GCC CFLAGS="-O2 -mcpu=cortex-a9" make
   fi
   if [ $ARCH = "aarch64"  ]; then
        CC=$GCC CFLAGS="-O2 -mcpu=cortex-a57" make       # XCFLAGS=" -mabi=lp64 " compile
   fi
   popd

}

build_tiny

